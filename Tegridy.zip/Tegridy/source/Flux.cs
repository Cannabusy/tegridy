﻿using System.Text;
using Newtonsoft.Json.Linq;
using Flux.Crypto;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Utilities.Encoders;
using Org.BouncyCastle.Crypto.Parameters;

namespace Flux;
public class Auth
{
    private const string FLUX_URL = "http://fluxauth.com";
    private const string USER_AGENT = "FluxC#/1.0";
    private static readonly string PublicKey = @"-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAo0Atw2cbl/I3ngK0b6WP
7oNNTzu+BFYXcv0xszCHDhjNWGwl4M4oOQkLgUf0Fpu1kN2kdf8zU19FPiK9dzDT
DCzp3LkSb5EzgSBM2lrwuakseh3ZLJYp4K6dflVwKQT5VFiK3hI/WA86hDY5WnQZ
bRRyPjT9PTPuxXdS4g5Fq34OG5QWXCIvp/LipRoT89ESbGeJDff2OwfaF5afqCiX
q64OMBYx+Mw+PGObll+KFkGX5rpwjJ0jmSZvdtoGj4l7YAu0nex1p6RarhE/QeuK
4Bc1qjmvuRbpkF6Qh1fagjA3xeBFzIwuUtJbkHT0/KwDj0eh9JhFyExR7S8eJQ4A
gwIDAQAB
-----END PUBLIC KEY-----";
    private static string _application = "";

    public static string Application
    {
        get => _application;
        set => _application = value;
    }

    public static JObject? Response { get; private set; }

    public static void Authenticate(string license, string? hwid)
    {
        if (string.IsNullOrEmpty(_application)) throw new Exception("uninitialized");
        if (string.IsNullOrEmpty(hwid)) hwid = "";

        var rawPayload = JObject.FromObject(new { license, hwid, randomness = new Random().Next(256) }).ToString();

        using var client = new HttpClient { BaseAddress = new Uri(FLUX_URL) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd(USER_AGENT);
        var content = new StringContent(CryptoUtils.EncryptMultipartMessage(rawPayload, PublicKey), Encoding.UTF8, "text/plain");
        var response = client.PostAsync($"/api/v1/{_application}/authenticate?secure=true", content).Result;
        var responseBody = response.Content.ReadAsStringAsync().Result;
        Response = JObject.Parse(CryptoUtils.DecryptMultipartMessage(responseBody, PublicKey));
        if (Response == null) throw new Exception("null response");

        var error = Response.GetValue("error");
        if (error != null) throw new Exception(error.ToString());

        var success = Response.GetValue("success");
        if (success == null) throw new Exception("null success");
        if (!success.ToObject<bool>())
        {
            throw new Exception("unauthorized");
        }
    }

    public static T? GetField<T>(string fieldName)
    {
        if (Response == null) throw new Exception("unauthorized");
        var value = Response.GetValue(fieldName);
        if (value == null)
            throw new Exception($"field {fieldName} not found");

        return value.Value<T>();
    }

    public static T? GetVariable<T>(string variableName)
    {
        if (string.IsNullOrEmpty(_application)) throw new Exception("uninitialized");

        using var client = new HttpClient { BaseAddress = new Uri(FLUX_URL) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd(USER_AGENT);

        if (Response != null)
        {
            var token = Response.GetValue("token");
            if (Response != null && Response.TryGetValue("token", out token))
                client.DefaultRequestHeaders.Add("X-Serial-Token", token.ToString());
        }

        var response = client.GetAsync($"/api/v1/{_application}/variables/{variableName}").Result;
        var responseBody = response.Content.ReadAsStringAsync().Result;
        var jsonResponse = JObject.Parse(CryptoUtils.DecryptMultipartMessage(responseBody, PublicKey));

        var error = jsonResponse.GetValue("error");
        if (error != null) throw new Exception(error.ToString());

        var value = jsonResponse.GetValue("value");
        if (value == null) throw new Exception("null value");
        return value.Value<T>();
    }

    public static byte[] DownloadVariable(string variableName)
    {
        if (string.IsNullOrEmpty(_application)) return new byte[] { };
        using var client = new HttpClient { BaseAddress = new Uri(FLUX_URL) };
        client.DefaultRequestHeaders.UserAgent.ParseAdd(USER_AGENT);

        if (Response != null)
        {
            var token = Response.GetValue("token");
            if (Response != null && Response.TryGetValue("token", out token))
                client.DefaultRequestHeaders.Add("X-Serial-Token", token.ToString());
        }

        var response = client.GetAsync($"/api/v1/{_application}/variables/{variableName}").Result;
        var responseBody = response.Content.ReadAsByteArrayAsync().Result;

        var fileKey = "fe6a2d7c37445e4a7de18cb05ce2891cb3ba8493cf434b086bb50ad27d90f90a";

        byte[] key = Hex.Decode(fileKey);
        var iv = new byte[16];
        Array.Copy(responseBody, iv, 16);
        var encryptedData = new byte[responseBody.Length - 16];
        Array.Copy(responseBody, 16, encryptedData, 0, encryptedData.Length);

        IBufferedCipher cipher = new PaddedBufferedBlockCipher(new CbcBlockCipher(new AesEngine()), new Pkcs7Padding());
        cipher.Init(false, new ParametersWithIV(new KeyParameter(key), iv));
        byte[] decryptedData = new byte[cipher.GetOutputSize(encryptedData.Length)];
        int length = cipher.ProcessBytes(encryptedData, 0, encryptedData.Length, decryptedData, 0);
        length += cipher.DoFinal(decryptedData, length);

        byte[] result = new byte[length];
        Array.Copy(decryptedData, 0, result, 0, length);

        return decryptedData;
    }
}