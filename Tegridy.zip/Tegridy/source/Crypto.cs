﻿using System.Text;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Crypto.Encodings;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;

namespace Flux.Crypto
{
    public static class CryptoUtils
    {
        public static string PublicEncrypt(string message, string publicKeyStr)
        {
            var publicKeyBytes = Encoding.UTF8.GetBytes(publicKeyStr);
            var publicKey = (AsymmetricKeyParameter)new PemReader(new StreamReader(new MemoryStream(publicKeyBytes))).ReadObject();
            var encryptEngine = new OaepEncoding(new RsaEngine());
            encryptEngine.Init(true, publicKey);

            var messageBytes = Encoding.UTF8.GetBytes(message);
            var encryptedMessageBytes = encryptEngine.ProcessBlock(messageBytes, 0, messageBytes.Length);

            return Convert.ToBase64String(encryptedMessageBytes);
        }

        public static string PublicDecrypt(string encryptedData, string publicKeyStr)
        {
            byte[] encryptedBytes = Convert.FromBase64String(encryptedData);
            RsaKeyParameters publicKey = ReadPublicKeyFromString(publicKeyStr);

            byte[] decryptedBytes = PublicDecrypt(encryptedBytes, publicKey);
            int i = 0;
            while (decryptedBytes[i] != 0)
                i++;

            byte[] trimmedBytes = new byte[decryptedBytes.Length - i - 1];
            Array.Copy(decryptedBytes, i + 1, trimmedBytes, 0, trimmedBytes.Length);

            return Encoding.UTF8.GetString(trimmedBytes);
        }

        private static RsaKeyParameters ReadPublicKeyFromString(string publicKeyStr)
        {
            using (TextReader publicKeyReader = new StringReader(publicKeyStr))
            {
                PemReader pemReader = new PemReader(publicKeyReader);
                return (RsaKeyParameters)pemReader.ReadObject();
            }
        }

        private static byte[] PublicDecrypt(byte[] encryptedData, RsaKeyParameters publicKey)
        {
            IAsymmetricBlockCipher cipher = new Org.BouncyCastle.Crypto.Engines.RsaEngine();
            cipher.Init(false, publicKey); // false for decryption

            return cipher.ProcessBlock(encryptedData, 0, encryptedData.Length);
        }

        public static string DecryptMultipartMessage(string message, string publicKey)
        {
            var parts = new List<string>(message.Split('|'));
            var decryptedMessage = new StringBuilder();

            foreach (var part in parts)
            {
                decryptedMessage.Append(PublicDecrypt(part, publicKey));
            }

            return decryptedMessage.ToString();
        }

        public static string EncryptMultipartMessage(string message, string publicKey)
        {
            var encryptedMessage = new StringBuilder();
            string encryptedPart;

            for (int i = 0; i < message.Length; i += 214)
            {
                encryptedPart = PublicEncrypt(message.Substring(i, Math.Min(214, message.Length - i)), publicKey);
                encryptedMessage.Append(encryptedPart).Append("|");
            }

            encryptedMessage.Length -= 1;

            return encryptedMessage.ToString();
        }
    }
}